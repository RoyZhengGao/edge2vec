import argparse
import networkx as nx
import matplotlib.pyplot as plt
import random
import numpy as np

import matplotlib.pyplot as plt

from gensim.models import Word2Vec

from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.cluster import KMeans
from sklearn import metrics
'''
first version: unweighted, undirected network
'''
def parse_args():
    '''
    Parses the node2vec arguments.
    '''
    parser = argparse.ArgumentParser(description="Run node2vec.")
    parser.add_argument('--reduction', type=int, default='0',
                        help='dimension reduction method')

    parser.add_argument('--m1', type=int, default='7',
                        help='barbell graph m1')

    parser.add_argument('--m2', type=int, default='1',
                        help='barbell graph m2')

    parser.add_argument('--input', nargs='?', default='barbell.txt',
                        help='Input graph path')

    parser.add_argument('--output', nargs='?', default='barbell_edge2vec.txt',
                        help='Embeddings path')

    parser.add_argument('--dimensions', type=int, default=10,
                        help='Number of dimensions. Default is 128.')

    parser.add_argument('--walk-length', type=int, default=5,
                        help='Length of walk per source. Default is 80.')

    parser.add_argument('--num-walks', type=int, default=10,
                        help='Number of walks per source. Default is 10.')

    parser.add_argument('--window-size', type=int, default=5,
                        help='Context size for optimization. Default is 10.')

    parser.add_argument('--iter', default=10, type=int,
                      help='Number of epochs in SGD')

    parser.add_argument('--workers', type=int, default=8,
                        help='Number of parallel workers. Default is 8.')

    parser.add_argument('--p', type=float, default=1,
                        help='Return hyperparameter. Default is 1.')

    parser.add_argument('--q', type=float, default=1,
                        help='Inout hyperparameter. Default is 1.')

    parser.add_argument('--weighted', dest='weighted', action='store_true',
                        help='Boolean specifying (un)weighted. Default is unweighted.')
    parser.add_argument('--unweighted', dest='unweighted', action='store_false')
    parser.set_defaults(weighted=False)

    parser.add_argument('--directed', dest='directed', action='store_true',
                        help='Graph is (un)directed. Default is undirected.')
    parser.add_argument('--undirected', dest='undirected', action='store_false')
    parser.set_defaults(directed=False)

    return parser.parse_args()

def generate_graph_write_edgelist(m1,m2,edgeList):
    target = open(edgeList, 'w') 
    G=nx.barbell_graph(m1,m2)
    # print G.edges()
    i = 0
    for edge in G.edges():
        i = i+1
        output = str(edge[0])+" "+str(edge[1])+" 1 " +str(i)+"\n" 
        target.write(output)
    target.close()
    # nx.write_edgelist(G, "barbell.txt")
def read_graph(edgeList,weighted=False, directed=False):
    '''
    Reads the input network in networkx.
    '''
    if weighted:
        G = nx.read_edgelist(edgeList, nodetype=int, data=(('weight',float),('id',int)), create_using=nx.DiGraph())
    else:
        G = nx.read_edgelist(edgeList, nodetype=int,data=(('weight',float),('id',int)), create_using=nx.DiGraph())
        for edge in G.edges():
            G[edge[0]][edge[1]]['weight'] = 1

    if not directed:
        G = G.to_undirected()

    # print (G.edges(data = True))
    return G

def draw_graph(G):
    # nx.draw(G)
    pos = nx.spring_layout(G)

    nx.draw_networkx_nodes(G, pos, node_color="w")
    nx.draw_networkx_edges(G, pos, width=1)
    nx.draw_networkx_edge_labels(G, pos)
    nx.draw_networkx_labels(G, pos ,font_size=16, font_color="black")

    plt.xticks([])
    plt.yticks([])
    plt.show()
    plt.show()

def simulate_walks(G, num_walks, walk_length):
    walks = []
    links = list(G.edges(data = True))
    print 'Walk iteration:'
    for walk_iter in range(num_walks):
        print str(walk_iter+1), '/', str(num_walks)
        random.shuffle(links)
        for link in links:
            print "chosen link id: ",link[2]['id']
            walks.append(node2vec_walk(G, walk_length, link))

    return walks

def node2vec_walk(G, walk_length, start_link): 
    print "start link: ", type(start_link), start_link
    walk = [start_link] 
    result = [str(start_link[2]['id'])]
    print "result ",result
    while len(walk) < walk_length:
        cur = walk[-1]
        start_node = cur[0]
        end_node = cur[1]

        '''
        find the direction of link to go. If a node degree is 1, it means if go that direction, there is no other links to go further
        if the link are the only link for both nodes, the link will have no neighbours (need to have teleportation later)
        '''
        start_direction = 0
        end_direction = 0
        if G.degree(start_node) > 1:
            start_direction = 1.0/G.degree(start_node)
        if G.degree(end_node) > 1: 
            end_direction = 1.0/G.degree(end_node)
        prob = start_direction/(start_direction+end_direction)
        # print "start node: ", start_node, " degree: ", G.degree(start_node)
        # print "end node: ", end_node, " degree: ", G.degree(end_node)

        # print cur[0], cur[1]
        rand = np.random.rand() 
        # print "random number ",rand
        # print "probability for start node: ",prob

        if prob >= rand:
            # print "yes"
            direction_node = start_node
            left_node = end_node
        else:
            direction_node = end_node
            left_node = start_node
        print "directed node: ",direction_node
        print "left_node node: ",left_node
        '''
        here to choose which link goes to. There are three conditions for the link based on node distance. 0,1,2
        '''
        neighbors = G.neighbors(direction_node)
        # print G.has_edge(1,3)
        # print G.has_edge(3,1)
        '''
        calculate sum of distance
        '''
        distance_sum = 0
        for neighbor in neighbors:
            print "neighbors:", neighbor
            if G.has_edge(neighbor,left_node):#undirected graph
                distance_sum += 1.0/(1+1) #+1 normalization
            # elif neighbor == left_node:
            #     distance_sum += 1.0/(0+1)
            else:
                distance_sum += 1.0/(1+2)

        '''
        pick up the next step link
        '''
        random.shuffle(neighbors)
        rand = np.random.rand() * distance_sum
        threshold = 0

        for neighbor in neighbors:
            if G.has_edge(neighbor,left_node):#undirected graph
                threshold += 1.0/(1+1) #+1 normalization
                if threshold >= rand:
                    next_link_end_node = neighbor
                    break;
            # elif neighbor == left_node:
            #     distance_sum += 1.0/(0+1)
            else:
                threshold += 1.0/(1+2)
                if threshold >= rand:
                    next_link_end_node = neighbor
                    break;

        print "distance_sum: ",distance_sum
        print "next_link_end_node: ",next_link_end_node
        next_link = G[direction_node][next_link_end_node]
        # next_link = G.get_edge_data(direction_node,next_link_end_node)
        
        next_link_tuple = tuple()
        next_link_tuple += (direction_node,)
        next_link_tuple += (next_link_end_node,)
        next_link_tuple += (next_link,)
        print type(next_link_tuple)
        print next_link_tuple
        walk.append(next_link_tuple)
        result.append(str(next_link_tuple[2]['id']))
        print "walk length: ",len(walk),walk
    print "path: ",result
    return result


def main(args): 
    # print "------begin to write graph---------"
    # generate_graph_write_edgelist(args.m1,args.m2,args.input)
    print "------begin to read graph---------"
    G = read_graph(args.input,True,False)
    # G=nx.barbell_graph(17,1)
    # draw_graph(G) 
    print "------begin to simulate walk---------"
    walks = simulate_walks(G,args.num_walks, args.walk_length)
    # print walks
    print "------begin to calculate word2vec---------"
    model = Word2Vec(walks, size=args.dimensions, window=args.window_size, min_count=0, sg=1, workers=args.workers, iter=args.iter)
    X = model[model.wv.vocab]
    # print type(model.wv.vocab)
    # print type(X),X[18]
    # print model.wv['1']
    length = len(model.wv.vocab)
    y = []
    X = []
    target_names = ['left','right']
    for key in model.wv.vocab:
        # print key,type(model.wv[key])
        X.append(model.wv[key])
        if int(key)> length/2:  
            y.append(1)
        else: 
            y.append(0)
    y = np.asarray(y)
    

    # print X,y
    if args.reduction == 0:
        plt.title('PCA Dimension reduction result, d='+str(args.dimensions))
        pca = PCA(n_components=2)
        X_r = pca.fit(X).transform(X)
    else:
        plt.title('T-SNE Dimension reduction result, d='+str(args.dimensions))
        tsne = TSNE(n_components=2) 
        X_r = tsne.fit_transform(X)
    # lda = LinearDiscriminantAnalysis(n_components=2)
    # X_r = lda.fit_transform(X,y)
    
    print X_r,type(X_r)
    print y,type(y)
    colors = ['navy', 'turquoise']
    lw = 2 
    for color, i, target_name in zip(colors, [0, 1], target_names):
        plt.scatter(X_r[y == i, 0], X_r[y == i, 1], color=color, alpha=.8, lw=lw,
                    label=target_name)
    plt.legend(loc='best', shadow=False, scatterpoints=1)
    # plt.scatter(X_tsne[:, 0], X_tsne[:, 1])
    plt.show()
    model.wv.save_word2vec_format(args.output)
    # kmeans = KMeans(X_r,n_clusters=2) 
    kmeans = KMeans(n_clusters=2)
    kmeans.fit(X_r)
    labels = kmeans.labels_
    #------evaluation-------------
    #Adjusted Rand index
    ri = metrics.adjusted_rand_score(y, labels) 
    #Mutual Information based scores
    mi = metrics.adjusted_mutual_info_score(y, labels)
    #Homogeneity, completeness and V-measure
    v = metrics.homogeneity_completeness_v_measure(y, labels)
    #Fowlkes-Mallows scores
    fm = metrics.fowlkes_mallows_score(y, labels) 
    print kmeans,labels,ri,mi,v,fm
    print "------finish!---------"

if __name__ == "__main__":
    args = parse_args()
    main(args)   
