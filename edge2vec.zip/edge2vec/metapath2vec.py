import numpy as np
import networkx as nx
import random
import argparse
'''
first version: unweighted, undirected network
'''
def parse_args():
    '''
    Parses the metapath2vec arguments.
    '''
    parser = argparse.ArgumentParser(description="Run metapath2vec.") 

    parser.add_argument('--input', nargs='?', default='/Users/gaozheng/Dropbox/research/sigir_work_with_ding_ying_group/toy_example/toy_example2/toy_example.txt',
                        help='Input graph path')

    parser.add_argument('--output', nargs='?', default='/Users/gaozheng/Dropbox/research/sigir_work_with_ding_ying_group/toy_example/toy_example2/random_walk.txt',
                        help='random walk corpus')

    parser.add_argument('--metapath', nargs='?', default='/Users/gaozheng/Dropbox/research/sigir_work_with_ding_ying_group/toy_example/toy_example2/metapath.txt',
                        help='random walk corpus')

    parser.add_argument('--node-type', nargs='?', default='/Users/gaozheng/Dropbox/research/sigir_work_with_ding_ying_group/toy_example/toy_example2/node_type.txt',
                        help='random walk corpus')

    parser.add_argument('--dimensions', type=int, default=10,
                        help='Number of dimensions. Default is 128.')

    parser.add_argument('--walk-length', type=int, default=10,
                        help='Length of walk per source. Default is 80.')

    parser.add_argument('--num-walks', type=int, default=1,
                        help='Number of walks per source. Default is 10.')

    parser.add_argument('--window-size', type=int, default=5,
                        help='Context size for optimization. Default is 10.')

    parser.add_argument('--iter', default=10, type=int,
                      help='Number of epochs in SGD')

    parser.add_argument('--workers', type=int, default=8,
                        help='Number of parallel workers. Default is 8.')

    parser.add_argument('--p', type=float, default=1,
                        help='Return hyperparameter. Default is 1.')

    parser.add_argument('--q', type=float, default=1,
                        help='Inout hyperparameter. Default is 1.')

    parser.add_argument('--weighted', dest='weighted', action='store_true',
                        help='Boolean specifying (un)weighted. Default is unweighted.')
    parser.add_argument('--unweighted', dest='unweighted', action='store_false')
    parser.set_defaults(weighted=False)

    parser.add_argument('--directed', dest='directed', action='store_true',
                        help='Graph is (un)directed. Default is undirected.')
    parser.add_argument('--undirected', dest='undirected', action='store_false')
    parser.set_defaults(directed=False)

    return parser.parse_args()

def simulate_walks(G, num_walks,walk_length,p,q,path):
    walks = []
    nodes = list(G.nodes(data = True))
    print 'Walk iteration:'
    for walk_iter in range(num_walks):
        print str(walk_iter+1), '/', str(num_walks)
        random.shuffle(nodes)
        for node in nodes:
            if node[1]['type'] == path[0]:
                walk = node2vec_walk(G, walk_length, node,p,q,path)
            # if len(walk) > 0:
                walks.append(walk) 
    return walks

def node2vec_walk(G,walk_length,start_node,p,q,path):
    path_len = len(path)
    print "start node: ", type(start_node), start_node
    walk = [start_node[0]] 
    while len(walk) < walk_length:# here we may need to consider some dead end issues
        next_node_type_id = len(walk)%path_len
        next_node_type = path[next_node_type_id]
        cur = walk[-1][0]
        # print cur
        cur_nbrs =sorted(G.neighbors(cur)) #(G.neighbors(cur))
        # print cur_nbrs
        good_nbrs = [] #here we use a list to contain eligible next step nodes: need to follow the metapath 
        for cur_nb in cur_nbrs: 
            if G.nodes[cur_nb]['type'] == next_node_type:
                good_nbrs.append(cur_nb)

        random.shuffle(good_nbrs)

        if len(good_nbrs) > 0:
            if len(walk) == 1:
                rand = int(np.random.rand()*len(good_nbrs))
                next =  good_nbrs[rand]
                walk.append(next) 
            else:
                prev = walk[-2][0] 
                distance_sum = 0
                for neighbor in good_nbrs:  
                    if G.has_edge(neighbor,prev):#undirected graph
                        
                        distance_sum += p #+1 normalization
                    # elif neighbor == left_node: #decide whether it can random walk back
                    #     distance_sum += 1.0/(0+1)
                    else:
                        distance_sum += q

                '''
                pick up the next step link
                ''' 

                rand = np.random.rand() * distance_sum
                threshold = 0 
                for neighbor in good_nbrs: 
                    
                    if G.has_edge(neighbor,prev):#undirected graph
                        
                        threshold += p  
                        if threshold >= rand:
                            next = neighbor
                            break;
                            
                    else:
                        threshold += q
                        if threshold >= rand:
                            next = neighbor
                            break;

                walk.append(next) 
        else:
            break #if only has 1 neighbour 
 
        # print "walk length: ",len(walk),walk
        # print "edge walk: ",len(edge_walk),edge_walk 
    return walk 
def read_graph(edgeList,weighted=False, directed=False):
    '''
    Reads the input network in networkx.
    '''
    if weighted:
        G = nx.read_edgelist(edgeList, nodetype=str,data=(('type',int),), create_using=nx.DiGraph())
    else:
        G = nx.read_edgelist(edgeList, nodetype=str,data=(('type',int),), create_using=nx.DiGraph())
        for edge in G.edges():
            G[edge[0]][edge[1]]['weight'] = 1

    if not directed:
        G = G.to_undirected()

    # print (G.edges(data = True)) 
    # print type(G.nodes['11']),type(G.nodes)
    # G.nodes['11']["type"] = "1"
    
    return G

def add_node_type(file,G):
    with open(file) as f:
        for line in f:
            result = line.rstrip().split(" ")
            node_id = result[0]
            node_type = result[1]
            G.nodes[node_id]["type"] = node_type
            
#metapath intentionally remove the last node to make the random walk follow the metapaths
#e.g. 2 3 3 2 --> 2 3 3 so that the random walk can be 2 3 3 2 3 3 2 3 3 ...
def read_metapath(file):
    metapath = []
    with open(file) as f:
        for line in f:
            metapath.append(line.rstrip())
    path = metapath[1]
    return path.split(" ")

def save_walks(walks,output_file):
    bw = open(output_file, 'w')
    for walk in walks:
        walk_str = ' '.join(str(e) for e in walk)
        bw.write("%s\n" % walk_str)
    bw.close()

def main(args):    
    G = read_graph(args.input,True,False)  
    # print G.nodes(data = True)
    add_node_type(args.node_type,G)
    # print G.nodes(data = True)
    path = read_metapath(args.metapath)
    # print path,type(path)
    walks = simulate_walks(G, args.num_walks, args.walk_length,args.p,args.q,path) 
    # print type(walks),walks
    save_walks(walks,args.output)
 
if __name__ == "__main__":
    args = parse_args()
    main(args)   
