import argparse
import networkx as nx
import matplotlib.pyplot as plt
import random
import numpy as np   
import math
from scipy import stats
from scipy import spatial

'''
first version: unweighted, undirected network
use node2vec to generate edge transction matrix based on EM algorithm
'''
def parse_args():
    '''
    Parses the node2vec arguments.
    '''
    parser = argparse.ArgumentParser(description="Run edge transaction matrix.") 

    parser.add_argument('--input', nargs='?', default='/Users/gaozheng/Dropbox/research/sigir_work_with_ding_ying_group/toy_example/toy_example2/toy_example.txt',
                        help='Input graph path')

    parser.add_argument('--output', nargs='?', default='transaction_matrix.txt',
                        help='transaction matrix file')
    
    parser.add_argument('--type_size', type=int, default=3,
                        help='Number of edge types. Default is 3.')

    parser.add_argument('--metapath', nargs='?', default='/Users/gaozheng/Dropbox/research/sigir_work_with_ding_ying_group/toy_example/toy_example2/metapath_pair.txt',
                        help='Input graph path')

    parser.add_argument('--em_iteration', default=10, type=int,
                      help='EM iterations for transaction matrix')

    parser.add_argument('--e_step', default=3, type=int,
                      help='E step in the EM algorithm: there are four expectation metrics')
    
    parser.add_argument('--dimensions', type=int, default=10,
                        help='Number of dimensions. Default is 128.')

    parser.add_argument('--walk-length', type=int, default=50,
                        help='Length of walk per source. Default is 80.')

    parser.add_argument('--num-walks', type=int, default=1,
                        help='Number of walks per source. Default is 10.')

    parser.add_argument('--window-size', type=int, default=5,
                        help='Context size for optimization. Default is 10.')

    parser.add_argument('--iter', default=10, type=int,
                      help='Number of epochs in SGD')

    parser.add_argument('--workers', type=int, default=8,
                        help='Number of parallel workers. Default is 8.')

    parser.add_argument('--p', type=float, default=1,
                        help='Return hyperparameter. Default is 1.')

    parser.add_argument('--q', type=float, default=1,
                        help='Inout hyperparameter. Default is 1.')

    parser.add_argument('--weighted', dest='weighted', action='store_true',
                        help='Boolean specifying (un)weighted. Default is unweighted.')
    parser.add_argument('--unweighted', dest='unweighted', action='store_false')
    parser.set_defaults(weighted=False)

    parser.add_argument('--directed', dest='directed', action='store_true',
                        help='Graph is (un)directed. Default is undirected.')
    parser.add_argument('--undirected', dest='undirected', action='store_false')
    parser.set_defaults(directed=False)

    return parser.parse_args()

def read_metapath_pair(file):
    metapath = []
    with open(file) as f:
        for line in f:
            result = line.rstrip().split(" ")
            tur = list()
            tur.append(int(result[0])-1)
            tur.append(int(result[1])-1)
            metapath.append(tur)
    return metapath


def read_graph(edgeList,weighted=False, directed=False):
    '''
    Reads the input network in networkx.
    '''
    if weighted:
        G = nx.read_edgelist(edgeList, nodetype=str, data=(('type',int),), create_using=nx.DiGraph())
    else:
        G = nx.read_edgelist(edgeList, nodetype=str,data=(('type',int),), create_using=nx.DiGraph())
        for edge in G.edges():
            G[edge[0]][edge[1]]['weight'] = 1

    if not directed:
        G = G.to_undirected()

    # print (G.edges(data = True))
    return G
 
def initialize_edge_type_matrix(type_num,metapath_pair):
    # initialized_val = 1.0/(type_num*type_num)
    matrix = [ [ 0 for i in range(type_num) ] for j in range(type_num) ]
    for pair in metapath_pair:
        matrix[pair[0]][pair[1]] = 1
        matrix[pair[1]][pair[0]] = 1
    return matrix


def simulate_walks(G, num_walks, walk_length,matrix,p,q):
    walks = []
    nodes = list(G.nodes())
    print 'Walk iteration:'
    for walk_iter in range(num_walks):
        print str(walk_iter+1), '/', str(num_walks)
        random.shuffle(nodes)
        count = 1000
        for node in nodes:
            # print "chosen node id: ",nodes
            walks.append(hetero_node2vec_walk(G, walk_length, node,matrix,p,q)) 
            count = count - 1
            if count == 0 or len(walks)>1000:#control the pairwise list length
                break
    return walks

def hetero_node2vec_walk(G, walk_length, start_node,matrix,p,q): 
    print "start node: ", type(start_node), start_node
    walk = [start_node] 
    edge_walk = [] 
    while len(walk) < walk_length:# here we may need to consider some dead end issues
        cur = walk[-1]
        cur_nbrs =sorted(G.neighbors(cur)) #(G.neighbors(cur))
        random.shuffle(cur_nbrs)
        if len(cur_nbrs) > 0:
            if len(walk) == 1:
                rand = int(np.random.rand()*len(cur_nbrs))
                next =  cur_nbrs[rand]
                walk.append(next)
                edge_walk.append(G[cur][next]['type'])
            else:
                prev = walk[-2]
                pre_edge_type = G[prev][cur]['type']
                distance_sum = 0
                for neighbor in cur_nbrs:
                    neighbor_link = G[cur][neighbor] 
                    # print "neighbor_link: ",neighbor_link
                    neighbor_link_type = neighbor_link['type']
                    # print "neighbor_link_type: ",neighbor_link_type
                    trans_weight = matrix[pre_edge_type-1][neighbor_link_type-1]
                    
                    if G.has_edge(neighbor,prev):#undirected graph
                        
                        distance_sum += trans_weight*p #+1 normalization
                    # elif neighbor == left_node: #decide whether it can random walk back
                    #     distance_sum += 1.0/(0+1)
                    else:
                        distance_sum += trans_weight*q

                '''
                pick up the next step link
                ''' 

                rand = np.random.rand() * distance_sum
                threshold = 0 
                for neighbor in cur_nbrs:
                    neighbor_link = G[cur][neighbor] 
                    # print "neighbor_link: ",neighbor_link
                    neighbor_link_type = neighbor_link['type']
                    # print "neighbor_link_type: ",neighbor_link_type
                    trans_weight = matrix[pre_edge_type-1][neighbor_link_type-1]
                    
                    if G.has_edge(neighbor,prev):#undirected graph
                        
                        threshold += trans_weight*p  
                        if threshold >= rand:
                            next = neighbor
                            break;
                            
                    else:
                        threshold += trans_weight*q
                        if threshold >= rand:
                            next = neighbor
                            break;
                if next is not None:

                    walk.append(next)
                    # print "next: ",str(next),"threshold: ",str(threshold),"next: ",next
                    edge_walk.append(G[cur][next]['type'])
                else:
                    break
        else:
            break #if only has 1 neighbour 
 
        # print "walk length: ",len(walk),walk
        # print "edge walk: ",len(edge_walk),edge_walk 
    return edge_walk  

'''
E step, update transaction matrix
'''
def update_trans_matrix(walks,type_size,evaluation_metric,metapath_pair):
    #here need to use list of list to store all edge type numbers and use KL divergence to update
    matrix = [ [ 0 for i in range(type_size) ] for j in range(type_size) ]
    repo = dict()
    for i in range(type_size):#initialize empty list to hold edge type vectors
        repo[i] = []

    for walk in walks:
        curr_repo = dict()#store each type number in current walk
        for edge in walk:
            edge_id = int(edge) - 1 
            if edge_id in curr_repo:
                curr_repo[edge_id] = curr_repo[edge_id]+1
            else:
                curr_repo[edge_id] = 1

        for i in range(type_size):
            
            # print "curr_repo[i]: ",curr_repo[i],type(curr_repo[i])
            if i in curr_repo:
                repo[i].append(curr_repo[i]) 
            else:
                repo[i].append(0) 
    
    for i in range(type_size):
        print "repo ",i, ": ",repo[i],type(repo[i])
        for j in range(type_size):  
            if evaluation_metric == 1:
                sim_score = cos_test(repo[i],repo[j])  
                matrix[i][j] = sim_score
                print "each pair of edge type sim_score: ", sim_score 
            elif evaluation_metric == 2:
                sim_score = spearmanr_test(repo[i],repo[j])  
                matrix[i][j] = sim_score
            elif evaluation_metric == 3:
                sim_score = pearsonr_test(repo[i],repo[j])  
                matrix[i][j] = sim_score 
            else:
                raise ValueError('not correct evaluation metric! You need to choose from 1-4')  

    metapath_matrix = [ [ 0 for i in range(type_size) ] for j in range(type_size) ]
    for pair in metapath_pair:
        metapath_matrix[pair[0]][pair[1]] = matrix[pair[0]][pair[1]] 
        metapath_matrix[pair[0]][pair[1]] = matrix[pair[1]][pair[0]] 
    return metapath_matrix

#pairwised judgement
def wilcoxon_test(v1,v2):# original metric: the smaller the more similar 
    result = stats.wilcoxon(v1, v2).statistic
    return 1/(math.sqrt(result)+1)

def entroy_test(v1,v2):#original metric: the smaller the more similar
    result = stats.entropy(v1,v2)
    return result

def spearmanr_test(v1,v2):#original metric: the larger the more similar 
    result = stats.mstats.spearmanr(v1,v2).correlation
    # return sigmoid(result)
    # return standardization(result)
    return relu(result)

def pearsonr_test(v1,v2):#original metric: the larger the more similar
    result = stats.mstats.pearsonr(v1,v2)[0]
    # return sigmoid(result)
    # return standardization(result)
    return relu(result)

def cos_test(v1,v2):
    return 1 - spatial.distance.cosine(v1, v2)

'''
for pearson and spearman test standardization
'''
def sigmoid(x):
  return 1 / (1 + math.exp(-x))

def standardization(x):
    return (x+1)/2

def relu(x):
    return (abs(x) + x) / 2
    
def main(args):  
    print "prepare metapath pairs"
    metapath_pair = read_metapath_pair(args.metapath) 
    print "begin to initialize transaction matrix"
    trans_matrix = initialize_edge_type_matrix(args.type_size,metapath_pair)
    print trans_matrix

    print "------begin to read graph---------"
    G = read_graph(args.input,True,False) 

    print "------begin to simulate walk---------"
    for i in range(args.em_iteration):
        walks = simulate_walks(G,args.num_walks, args.walk_length,trans_matrix,args.p,args.q)#M step
        print str(i), "th iteration for Upating transaction matrix!"
        trans_matrix = update_trans_matrix(walks,args.type_size,args.e_step,metapath_pair)#E step
        print "trans_matrix: ",trans_matrix
    # print walks 

    print "------finish!---------"
    np.savetxt(args.output, trans_matrix)
if __name__ == "__main__":
    args = parse_args()

    main(args)   
