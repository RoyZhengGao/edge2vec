import random
import numpy as np
# print random
rand = np.random.rand()*5

print rand
rand = int(rand)
print rand

a = [1,4,3,2,5]
print a[2],a[1]