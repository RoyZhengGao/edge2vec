from scipy import stats
import numpy as np
from scipy import spatial
import math
#not pairwised
def wilcoxon_ranksums_test(v1,v2):
    return stats.ranksums(v1, v2)


def kruskal_test(v1,v2):
    return stats.kruskal(v1, v2)

def kruskalwallis_test(v1,v2):
    return stats.mstats.kruskalwallis(v1,v2)

def ks_twosamp_test(v1,v2):
	return stats.mstats.ks_twosamp(v1,v2)


#pairwised
def wilcoxon_test(v1,v2):
    return stats.wilcoxon(v1, v2).statistic

def entroy_test(v1,v2):
	return stats.entropy(v1,v2)

def spearmanr_test(v1,v2):
    return stats.mstats.spearmanr(v1,v2)

def pearsonr_test(v1,v2):
	return stats.mstats.pearsonr(v1,v2)


#others 
def kl_divergence(v1,v2): 
    v1 = np.asarray(v1, dtype=np.float) 
    v2 = np.asarray(v2, dtype=np.float)
    return np.sum(np.where(v1 != 0, v1 * np.log(v1 / v2), 0))

def pointbiserialr_test(v1,v2):
    return stats.mstats.pointbiserialr(v1,v2)	

def friedmanchisquare_test(v1,v2):
	return stats.friedmanchisquare(v1,v2)


def ttest_ind_test(v1,v2):
	return stats.ttest_ind(v1,v2)

def cos_test(v1,v2):
    return 1 - spatial.distance.cosine(v1, v2)

def sigmoid(x):
  return 1 / (1 + math.exp(-x))

def standardization(x):
    return (x+1)/2
def relu(x):
    return (abs(x) + x) / 2
v1 = [1,2,3,4,5]
v2 = [1,3,2,4,5]
v3 = [1,2,3,4,5]
v4 = [2,4,6,8,10]
v5 = [5,4,3,2,1]
# v1 = [1, 3, 2, 3, 3, 3, 1, 2, 2, 1, 0, 4, 3, 1, 1, 3, 3, 0, 5, 0, 1, 1, 1, 3, 5, 3, 3, 1, 3, 4, 0]
# v2 = [4, 1, 1, 2, 2, 0, 1, 2, 0, 2, 1, 1, 1, 1, 2, 1, 1, 1, 0, 1, 0, 4, 1, 0, 0, 1, 1, 1, 1, 1, 0]


# print "entroy_test: ",entroy_test(v1,v2),entroy_test(v1,v3),entroy_test(v1,v4)
# print "wilcoxon_test: ",wilcoxon_test(v1,v2)#,wilcoxon_test(v1,v3),wilcoxon_test(v1,v4) 
# print "entroy_test: ",entroy_test(v1,v2)#,entroy_test(v1,v3),entroy_test(v1,v4)
# print "spearmanr_test: ",spearmanr_test(v1,v2)#,spearmanr_test(v1,v3),spearmanr_test(v1,v4)
# print "pearsonr_test: ",pearsonr_test(v1,v2)#,pearsonr_test(v1,v3),pearsonr_test(v1,v4)

# print "cosine: ",cos_test(v1,v2),cos_test(v1,v3),cos_test(v1,v4)



print sigmoid(-1),sigmoid(-0.5),sigmoid(0),sigmoid(0.5),sigmoid(1)
print standardization(-1),standardization(-0.5),standardization(0),standardization(0.5),standardization(1)
print relu(-1),relu(-0.5),relu(0),relu(0.5),relu(1)




